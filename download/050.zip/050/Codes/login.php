<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>登录</title>
</head>
<body>
	<div>
		<form action="dologin.php" method="post">
			用户名：<input type="text" name="username"><br />
			密&nbsp;&nbsp;码：<input type="password" name="pwd"><br />
			<input type="submit" name="sub" value="提交">
		</form>
	</div>
</body>
</html>



