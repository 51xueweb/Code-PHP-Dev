<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>主页</title>
</head>
<body>
	<p>这里是主页</p>
</body>
</html>