<!-- PHP实现网站生成桌面快捷方式 -->
<a href="shortcut.php?url=php.code.51xueweb.cn&name=PHP程序开发100例">生成桌面快捷方式</a>