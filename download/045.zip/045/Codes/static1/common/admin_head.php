<!-- 后台页面head公共部分 -->
<head>
	<title>河南中医药大学教学信息实时查询后台管理系统</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="./css/adminstyle.css">
	<script src="./js/showDate.js"></script>
</head>