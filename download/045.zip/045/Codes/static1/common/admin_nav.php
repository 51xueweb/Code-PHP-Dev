<nav>
	<img src="./images/logo.png">
	<a id="a_header1" class="a_header">河南中医药大学教学信息实时查询后台管理系统</a><br/>
	<a id="a_header2" class="a_header">Real time inquiry background management system of teaching information</a>
</nav>