<footer>
	<p>Copyright © 2016 橙子哩组合 版权所有</p>
</footer>