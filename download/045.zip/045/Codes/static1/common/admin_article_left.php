<div id="left">
	<table id="left_tab">
		<h3><center>功能列表</center></h3>
		<tr class="list_title"><th>管理员列表</th></tr>
		<tr class="list"><td><a href="./personal_info.php">个人信息</a></td></tr>
		<tr class="list"><td><a href="./personal_change_pwd.php">修改密码</a></td></tr>
		<tr class="list_title"><th>信息管理列表</th></tr>
		<tr class="list"><td><a href="./student_info.php">学生信息 </a></td></tr>
		<tr class="list"><td><a href="./teacher_info.php">教师信息</a></td></tr>
		<tr class="list"><td><a href="./course_info.php">课程信息</a></td></tr>
		<tr class="list"><td><a href="./room_info.php">教室信息</a></td></tr>
		<tr class="list"><td><a href="../class_info.php">班级信息</a></td></tr>
		<tr class="list"><td><a href="./zhouli_info.php">教学周历</a></td></tr>
		<tr class="list_title"><th><a href="./index.php">返回前台</a></th></tr>
		<tr class="list_title"><th><a href="./logout.php">退出系统</a></th></tr>
	</table>
</div>