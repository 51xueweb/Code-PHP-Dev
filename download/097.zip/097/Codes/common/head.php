<!--页面head公共部分 -->
<head>
	<title>图书信息管理系统</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="./css/style.css">
	<script src="./js/showDate.js"></script>
</head>