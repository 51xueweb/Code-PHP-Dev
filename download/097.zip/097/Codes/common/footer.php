<footer>
	<p>Copyright © 2017 河南中医药大学信息技术学院 版权所有</p>
</footer>