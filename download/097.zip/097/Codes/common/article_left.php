<div id="left">
	<table id="left_tab">
		<h3><center>功能列表</center></h3>
		<tr class="list_title"><th>个人列表</th></tr>
		<tr class="list"><td><a href="index.php">个人信息</a></td></tr>
		<tr class="list"><td><a href="change_pwd.php">修改密码</a></td></tr>
		<tr class="list_title"><th>图书列表</th></tr>
		<tr class="list"><td><a href="inquiry_book.php">查询图书</a></td></tr>
		<tr class="list"><td><a href="add_book.php">添加图书</a></td></tr>
		<tr class="list"><td><a href="manage_book.php">管理图书</a></td></tr>
		<tr class="list_title"><th><a href="logout.php">退出系统</a></th></tr>
	</table>
</div>