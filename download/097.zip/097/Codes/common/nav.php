<nav>
	<img src="./images/logo.png">
	<a id="a_header1" class="a_header">河南中医药大学信息技术学院图书信息管理系统</a><br/>
	<a id="a_header2" class="a_header">Library Information Management System Of The Information Technology College</a>
</nav>