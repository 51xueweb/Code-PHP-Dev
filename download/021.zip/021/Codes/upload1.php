 <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>文件上传</title>
</head>
<body>
	<form action="doAction3.php" method="post" enctype="multipart/form-data">
		请选择需要上传的文件：
		<input type="file" name="myFile"><br />
		<input type="submit" value="提交">


	</form>
</body>
</html>