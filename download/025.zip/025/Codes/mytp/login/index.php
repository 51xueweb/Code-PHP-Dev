<?php
	// 程序入口文件

	define('APP_DEBUG',true); // 开发调试模式
	require '../ThinkPHP/ThinkPHP.php';
?>
