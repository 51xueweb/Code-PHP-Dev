<?php
return array(
	//'配置项'=>'配置值'
	'APP_DEBUG'=>true,
	'DB_TYPE'=>'mysql',
	'DB_HOST'=>'localhost',
	'DB_NAME'=>'phpDemo',
	'DB_USER'=>'root',
	'DB_PWD'=>'',
	'DB_PORT'=>'3307',
	'DB_PREFIX'=>'',
	'SHOW_PAGE_TRACE'=>true  // 显示页面的trace信息
);