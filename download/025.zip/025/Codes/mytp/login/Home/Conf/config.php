<?php
return array(
	//'配置项'=>'配置值'
	'APP_DEBUG'=>true,
	'DB_TYPE'=>'mysql',
	'DB_HOST'=>'127.0.0.1',
	'DB_NAME'=>'thinkphp',
	'DB_USER'=>'root',
	'DB_PWD'=>'51xueweb',
	'DB_PORT'=>'3307',
	'DB_PREFIX'=>'',
	'SHOW_PAGE_TRACE'=>true  // 显示页面的trace信息
);