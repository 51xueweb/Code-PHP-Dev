<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>使用PHP生成条形码</title>
</head>
<body>
	<center>
	<h3>使用PHP生成条形码</h3>
		<form action="barcode.php" method="post">
			请输入11位货物编码：<input type="text" name="code">
			<input type="submit" name="sub" value="确定">
		</form>
	<center/>
</body>
</html>