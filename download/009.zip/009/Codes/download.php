<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
<a href="dog.jpg">下载dog.jpg</a>
<br />
<a href="test.zip">下载test.zip</a>
<br />
<a href="doDownload.php?filename=dog.jpg">通过程序下载dog.jpg</a>
<br />
</body>
</html>