<nav>
	<ul>
		<li><a href="home_index.php">首页</a></li>&nbsp;|&nbsp;
		<li><a href="home_index.php">参与投票</a></li>&nbsp;|&nbsp;
		<li><a href="addvote.php">发起投票</a></li>&nbsp;|&nbsp;
		<li><a href="myvote.php">我的投票</a></li>&nbsp;|&nbsp;
		<li><a href="change_pwd.php">修改密码</a></li>&nbsp;|&nbsp;
		<li><a href="logout.php">退出系统</a></li>
	</ul>	
</nav>