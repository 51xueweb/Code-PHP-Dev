<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>发红包</title>
</head>
<body>
<form action="redpacket.php" method="post">
	总	金	额：<input type="text" size="3" name="total"><br>
	红包个数：<input type="text" size="3" name="num"> 
	<input type="submit" value="发红包">
</form>
	
</body>
</html>