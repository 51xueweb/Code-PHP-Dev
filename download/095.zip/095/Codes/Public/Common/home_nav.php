<nav>
	<ul>
		<li><a href="personal_info.php">个人信息</a></li><li>|</li>
		<li><a href="change_pwd.php">修改密码</a></li><li>|</li>
		<li><a href="score.php">成绩查询</a></li><li>|</li>
		<li><a href="online_test.php">进入考试</a></li><li>|</li>
		<li><a href="logout.php">退出系统</a></li>
		<li class="date"><i>当前时间：<a id="showDate"></a></i></li>
	</ul>
</nav>