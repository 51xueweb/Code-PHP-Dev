<nav>
	<ul>
		<li><a href="admin_operate.php">个人信息</a></li><li>|</li>
		<li><a href="change_pwd.php">修改密码</a></li><li>|</li>
		<li><a href="student_info.php">考生信息</a></li><li>|</li>
		<li><a href="teacher_info.php">教师信息</a></li><li>|</li>
		<li><a href="test_info.php">试题信息</a></li><li>|</li>
		<li><a href="logout.php">退出系统</a></li>
	</ul>
</nav>