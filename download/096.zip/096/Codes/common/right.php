<div id="right">
	<a href="index.php">首页</a>&nbsp;|&nbsp;
	<a href="addmember.php">添加会员</a>&nbsp;|&nbsp;
	<a href="loss.php">卡挂失</a>&nbsp;|&nbsp;
	<a href="mylog.php">查看我的操作日志</a>&nbsp;|&nbsp;
	<a href="logout.php">退出系统</a>
</div>