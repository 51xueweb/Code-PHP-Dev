<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <form action="isbn_check.php" method="post">
        请输入需要校验的ISBN码：<br>
        <input type="text" name="isbn_num"><input type="submit" name="submit" value="开始校验">
    </form>
</body>
</html>