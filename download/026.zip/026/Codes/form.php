<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>

<body>
<form action="test.php" method="post">
	
		用户名：<input type="text" name="username"><br>
		密&nbsp;&nbsp;码：<input type="password" name="pwd"><br>
		<input type="submit" value="注册" name="reg">
		<input type="button" value="登录" name="login">
	
</form>
	
</body>
</html>


